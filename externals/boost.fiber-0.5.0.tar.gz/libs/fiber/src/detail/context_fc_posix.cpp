
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/fiber/detail/context.hpp>

#include <algorithm>
#include <cstdlib>
#include <cstring>

#include <boost/config.hpp>
#include <boost/system/system_error.hpp>

#include <boost/fiber/detail/fcontext.hpp>
#include <boost/fiber/exceptions.hpp>

namespace boost {
namespace fibers {
namespace detail {

struct context::impl_t : public fcontext_t
{};

context
context::current()
{
	context cn;
	cn.ctx_ = new impl_t();
	return boost::move( cn);
}

context
context::create( void( fn)( void *), void * vp, std::size_t stack_size)
{
	context cn;
	cn.ctx_ = new impl_t();
	get_fcontext( cn.ctx_);
#if defined(_POSIX_VERSION) && _POSIX_VERSION >= 199309
	int errno_ = ::posix_memalign( ( void **)( & cn.ctx_->fc_stack.ss_limit), ( std::size_t)( 2 * sizeof( void *) ), stack_size);
	if ( 0 != errno_)
		throw system::system_error(
			system::error_code(
				errno_,
				system::system_category) );
#else
#warning "no aligned memory allocation supported"
	cn.ctx_->fc_stack.ss_limit = std::malloc( stack_size);
	if ( 0 != cn.ctx_->fc_stack.ss_limit)
		throw system::system_error(
			system::error_code(
				system::errc::not_enough_memory,
				system::system_category) );
#endif
	cn.ctx_->fc_stack.ss_base = ( char *) cn.ctx_->fc_stack.ss_limit + stack_size;
	make_fcontext( cn.ctx_, fn, vp);
	return boost::move( cn);
}

context
context::create( void( fn)( void *), context const& next, void * vp, std::size_t stack_size)
{
	if ( ! next) throw context_moved(); 
	context cn;
	cn.ctx_ = new impl_t();
	get_fcontext( cn.ctx_);
#if defined(_POSIX_VERSION) && _POSIX_VERSION >= 199309
	int errno_ = ::posix_memalign( ( void **)( & cn.ctx_->fc_stack.ss_limit), ( std::size_t)( 2 * sizeof( void *) ), stack_size);
	if ( 0 != errno_)
		throw system::system_error(
			system::error_code(
				errno_,
				system::system_category) );
#else
#warning "no aligned memory allocation supported"
	cn.ctx_->fc_stack.ss_limit = std::malloc( stack_size);
	if ( 0 != cn.ctx_->fc_stack.ss_limit)
		throw system::system_error(
			system::error_code(
				system::errc::not_enough_memory,
				system::system_category) );
#endif
	cn.ctx_->fc_stack.ss_base = ( char *) cn.ctx_->fc_stack.ss_limit + stack_size;
	cn.ctx_->fc_link = next.ctx_;
	make_fcontext( cn.ctx_, fn, vp);
	return boost::move( cn);
}

context::context() :
	ctx_( 0)
{}

context::~context()
{
	if ( ctx_)
	{
#if defined(_POSIX_VERSION) && _POSIX_VERSION >= 199309
		std::free( ctx_->fc_stack.ss_limit);
#else
		std::free( ctx_->fc_stack.ss_limit);
#endif
		delete ctx_;
	}
}

context::context( BOOST_RV_REF( context) other) :
	ctx_( 0)
{ std::swap( ctx_, other.ctx_); }

context &
context::operator=( BOOST_RV_REF( context) other)
{
	if ( this != & other)
	{
		context tmp( other);
		swap( tmp);
	}
	return * this;
}

void
context::run()
{
	if ( ! ctx_) throw context_moved(); 
	set_fcontext( ctx_);
}

void
context::jump_to( context & other)
{
	if ( ! ctx_ || ! other) throw context_moved(); 
	swap_fcontext( ctx_, other.ctx_);
}

void
context::swap( context & other)
{ std::swap( ctx_, other.ctx_); }

bool
context::operator!() const
{ return 0 == ctx_; }

context::operator unspecified_bool_type() const
{ return 0 == ctx_ ? 0 : unspecified_bool; }

}}}
