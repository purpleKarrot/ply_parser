
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/fiber/mutex.hpp>

#include <boost/assert.hpp>
#include <boost/thread/thread.hpp>

#include <boost/fiber/utility.hpp>

namespace boost {
namespace fibers {

mutex::mutex() :
	oid_( this),
	state_( UNLOCKED),
	mtx_(),
	waiting_fibers_(),
	oidx_( waiting_fibers_.get< ordered_idx_tag >() ),
	sidx_( waiting_fibers_.get< sequenced_idx_tag >() )
{}

mutex::~mutex()
{ BOOST_ASSERT( waiting_fibers_.empty() ); }

void
mutex::lock()
{
	for (;;)
	{
		spin_mutex::scoped_lock lk( mtx_);
		if ( UNLOCKED == state_)
		{
			state_ = LOCKED;
			// TODO: store identifier of fiber/thread
			lk.unlock();
			break;
		}
		else if ( this_fiber::runs_as_fiber() )
		{
			fiber * f( strategy::active_fiber);
			BOOST_ASSERT( f);
			oidx_.insert( * f);
			BOOST_ASSERT( f->info_->st);
			f->info_->st->wait_for_object( oid_, lk);
		}
		else
		{
			lk.unlock();
			this_thread::yield();
		}
	}
}

bool
mutex::try_lock()
{
	spin_mutex::scoped_lock lk( mtx_);
	if ( LOCKED == state_) return false;
	state_ = LOCKED;
	return true;
}

void
mutex::unlock()
{
	// TODO: only the fiber/thread locked the mutex
	//       can call unlock()
	spin_mutex::scoped_lock lk( mtx_);
	state_ = UNLOCKED;
	if ( waiting_fibers_.empty() ) return;
	fiber f( * sidx_.begin() ); 
	sidx_.pop_front();
	BOOST_ASSERT( f.info_->st);
	f.info_->st->object_notify_one( oid_);
}

}}
