
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

// this file is based on config.hpp of boost.thread

#ifndef BOOST_FIBERS_DETAIL_CONFIG_H
#define BOOST_FIBERS_DETAIL_CONFIG_H

#include <boost/config.hpp>
#include <boost/detail/workaround.hpp>

# if BOOST_WORKAROUND(__BORLANDC__, < 0x600)
#   pragma warn -8008 // Condition always true/false
#   pragma warn -8080 // Identifier declared but never used
#   pragma warn -8057 // Parameter never used
#   pragma warn -8066 // Unreachable code
# endif

# if defined(BOOST_ALL_DYN_LINK) || defined(BOOST_FIBER_DYN_LINK)
#   undef  BOOST_FIBER_USE_LIB
#   define BOOST_FIBER_USE_DLL
# endif

# if defined(BOOST_WINDOWS_API) && defined(BOOST_POSIX_API)
#   error "Both BOOST_WINDOWS_API and BOOST_POSIX_API are defined!"
# elif ! defined(BOOST_WINDOWS_API ) && ! defined(BOOST_POSIX_API)
#   if defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(__CYGWIN__)
#     define BOOST_WINDOWS_API
#   else
#     define BOOST_POSIX_API
#   endif
# endif

# if defined(BOOST_FIBER_BUILD_DLL)   //Build dll
# elif defined(BOOST_FIBER_BUILD_LIB) //Build lib
# elif defined(BOOST_FIBER_USE_DLL)   //Use dll
# elif defined(BOOST_FIBER_USE_LIB)   //Use lib
# else //Use default
#   if defined(BOOST_FIBER_PLATFORM_WIN32)
#      if defined(BOOST_MSVC) || defined(BOOST_INTEL_WIN)
            //For compilers supporting auto-tss cleanup
            //with Boost.Threads lib, use Boost.Threads lib
#         define BOOST_FIBER_USE_LIB
#      else
            //For compilers not yet supporting auto-tss cleanup
            //with Boost.Threads lib, use Boost.Threads dll
#         define BOOST_FIBER_USE_DLL
#      endif
#   else
#      define BOOST_FIBER_USE_LIB
#   endif
# endif

# if defined(BOOST_HAS_DECLSPEC)
#   if defined(BOOST_FIBER_BUILD_DLL) //Build dll
#      define BOOST_FIBER_DECL __declspec(dllexport)
#   elif defined(BOOST_FIBER_USE_DLL) //Use dll
#      define BOOST_FIBER_DECL __declspec(dllimport)
#   else
#      define BOOST_FIBER_DECL
#   endif
# else
#   define BOOST_FIBER_DECL
# endif

// Automatically link to the correct build variant where possible.
# if ! defined(BOOST_ALL_NO_LIB) && ! defined(BOOST_FIBER_NO_LIB) && ! defined(BOOST_FIBER_BUILD_DLL) && ! defined(BOOST_FIBER_BUILD_LIB)

// Tell the autolink to link dynamically, this will get undef'ed by auto_link.hpp
# if defined(BOOST_FIBER_USE_DLL)
#   define BOOST_DYN_LINK
# endif

// Set the name of our library, this will get undef'ed by auto_link.hpp
# if defined(BOOST_FIBER_LIB_NAME)
#   define BOOST_LIB_NAME BOOST_FIBER_LIB_NAME
# else
#   define BOOST_LIB_NAME boost_fiber
# endif

// If we're importing code from a dll, then tell auto_link.hpp about it
// And include the header that does the work
#include <boost/config/auto_link.hpp>
# endif  // auto-linking disabled


// msvc/icc
#if defined(_MSC_VER)
#define BOOST_FIBER_TSSDECL __declspec(thread)

// i386
# if defined(_M_IX86)
#define BOOST_FIBER_NGREG	6
#define BOOST_FIBER_CALLDECL __cdecl
# endif

// gcc/icc
#elif defined(__GNUC__)
#define BOOST_FIBER_TSSDECL __thread

// i386
# if defined(__i386__)
#define BOOST_FIBER_NGREG	6
#define BOOST_FIBER_CALLDECL __attribute__((cdecl))

// x86_64
# elif defined(__x86_64__)
#define BOOST_FIBER_NGREG	9
#define BOOST_FIBER_CALLDECL

# endif

// POSIX ucontext
#elif defined(_POSIX_VERSION) && _POSIX_VERSION >= 200112L
#warning "this platform does not support fastcontext"

#else
#error "this platform is not supported"

#endif 

#endif // BOOST_FIBERS_DETAIL_CONFIG_H
