
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <sstream>
#include <stdexcept>
#include <string>

#include <boost/assert.hpp>
#include <boost/test/unit_test.hpp>
#include <boost/utility.hpp>

#include <boost/context.hpp>

int value1 = 0;
std::string value2;

void fn1( void *) {}

void fn2( void * vp)
{ value1 = * ( ( int *) vp); }

void fn3( void * vp)
{
	try
	{ throw std::runtime_error("abc"); }
	catch ( std::runtime_error const& e)
	{ value2 = e.what(); }
}

void test_case_1()
{
	boost::context c1( boost::context::create( fn1, 0, 65500) );
	BOOST_CHECK( c1);
	boost::context c2;
	BOOST_CHECK( ! c2);
}

void test_case_2()
{
	boost::context c1( boost::context::create( fn1, 0, 65500) );
	BOOST_CHECK( c1);
	boost::context c2( boost::move( c1) );
	BOOST_CHECK( ! c1);
	BOOST_CHECK( c2);
}

void test_case_3()
{
	boost::context c1( boost::context::create( fn1, 0, 65500) );
	BOOST_CHECK( c1);
	boost::context c2;
	BOOST_CHECK( ! c2);
	boost::swap( c1, c2);
	BOOST_CHECK( ! c1);
	BOOST_CHECK( c2);
}

void test_case_4()
{
	boost::context c1( boost::context::current() );
	BOOST_CHECK( c1);
	int i = 1;
	BOOST_CHECK_EQUAL( 0, value1);
	boost::context c2( boost::context::create( fn2, c1, & i, 65500) );
	BOOST_CHECK( c2);
	c1.jump_to( c2);
	BOOST_CHECK_EQUAL( 1, value1);
}

void test_case_5()
{
	boost::context c1( boost::context::current() );
	BOOST_CHECK_EQUAL( std::string(""), value2);
	boost::context c2( boost::context::create( fn3, c1, 0, 65500) );
	c1.jump_to( c2);
	BOOST_CHECK_EQUAL( std::string("abc"), value2);
}

boost::unit_test::test_suite * init_unit_test_suite( int, char* [])
{
	boost::unit_test::test_suite * test =
		BOOST_TEST_SUITE("Boost.Context: context test suite");

	test->add( BOOST_TEST_CASE( & test_case_1) );
	test->add( BOOST_TEST_CASE( & test_case_2) );
	test->add( BOOST_TEST_CASE( & test_case_3) );
	test->add( BOOST_TEST_CASE( & test_case_4) );
	test->add( BOOST_TEST_CASE( & test_case_5) );

	return test;
}
