#include <cstdlib>
#include <iostream>
#include <string>

#include <boost/bind.hpp>
#include <boost/system/system_error.hpp>

#include <boost/context.hpp>


void fn( void * vp)
{
	int i = * ( int *) vp;
	std::cout << "i == " << i << std::endl;
}

int main()
{
	try
	{
		int x = 7;

		boost::context ctx1, ctx2;

		ctx1 = boost::context::current();
		ctx2 = boost::context::create( fn, ctx1, & x, boost::context::default_stacksize);

		std::cout << "start" << std::endl;

		ctx1.jump_to( ctx2);

		std::cout << "finish" << std::endl;

		return EXIT_SUCCESS;
	}
	catch ( std::exception const& e)
	{ std::cerr << "exception: " << e.what() << std::endl; }
	catch (...)
	{ std::cerr << "unhandled exception" << std::endl; }
	return EXIT_FAILURE;
}
