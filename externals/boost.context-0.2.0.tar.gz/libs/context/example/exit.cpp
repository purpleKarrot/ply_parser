#include <cstdlib>
#include <iostream>
#include <string>

#include <boost/bind.hpp>
#include <boost/system/system_error.hpp>

#include <boost/context.hpp>

boost::context ctx1, ctx2;

void fn( void * vp)
{
	int i = * ( int *) vp;
	std::cout << "i == " << i << std::endl;
}

int main()
{
	try
	{
		int x = 7;

		ctx1 = boost::context::current();
		ctx2 = boost::context::create( fn, & x, boost::context::default_stacksize);

		ctx1.jump_to( ctx2);

		return EXIT_SUCCESS;
	}
	catch ( std::exception const& e)
	{ std::cerr << "exception: " << e.what() << std::endl; }
	catch (...)
	{ std::cerr << "unhandled exception" << std::endl; }
	return EXIT_FAILURE;
}
