
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CONTEXTS_DETAIL_FCONTEXT_H
#define BOOST_CONTEXTS_DETAIL_FCONTEXT_H

#include <boost/config.hpp>

#include <boost/context/detail/config.hpp>

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_PREFIX
#endif

namespace boost {
namespace contexts {
namespace detail {

typedef long int freg_t;

typedef freg_t fregset_t[BOOST_CONTEXT_NGREG];

typedef struct fstack	fstack_t;
struct fstack
{
	void	*	ss_base;
	void	*	ss_limit;
};

typedef struct fcontext	fcontext_t;
struct fcontext
{
	fregset_t		fc_reg;
	fstack_t		fc_stack;
	fcontext_t	*	fc_link;
#if defined(__i386__) || defined(__x86_64__) || defined(_M_IX86)
	short int		fc_x87_cw;
#endif
#if defined(_MSC_VER) && defined(_M_IX86)
	void		*	fc_excpt_lst;
	void		*	fc_local_storage;
#endif
};

extern "C" int BOOST_CONTEXT_CALLDECL get_fcontext( fcontext_t * fc);
extern "C" int BOOST_CONTEXT_CALLDECL set_fcontext( fcontext_t const* fc);
extern "C" int BOOST_CONTEXT_CALLDECL swap_fcontext( fcontext_t * ofc, fcontext_t const* nfc);
extern "C" int BOOST_CONTEXT_CALLDECL make_fcontext( fcontext_t * fc, void (* fn)( void *), void * p);

}}}

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_SUFFIX
#endif

#endif // BOOST_CONTEXTS_DETAIL_FCONTEXT_H

