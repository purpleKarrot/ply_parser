
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/fiber/detail/info_base.hpp>

#include <boost/system/system_error.hpp>

#include <boost/fiber/exceptions.hpp>
#include <boost/fiber/utility.hpp>

#include <boost/config/abi_prefix.hpp>

namespace boost {
namespace fibers {
namespace detail {

void trampoline( void * vp)
{
	BOOST_ASSERT( vp);
	detail::info_base * self( static_cast< detail::info_base * >( vp) );
	try
	{ self->enter(); }
	catch ( fiber_interrupted const&) {}
	catch (...) {}
	while ( ! self->at_exit.empty() )
	{
		detail::info_base::callable_type ca;
		self->at_exit.top().swap( ca);
		self->at_exit.pop();
		ca();
	}
 	this_fiber::cancel();
}

info_base::info_base( std::size_t stack_size) :
	use_count( 0),
	priority( 0),
	caller( context::current() ),
	callee( context::create( trampoline, this, stack_size) ),
	state( STATE_NOT_STARTED),
	interrupt( INTERRUPTION_DISABLED),
	at_exit(),
	st( 0)
{}

}}}

#include <boost/config/abi_suffix.hpp>
