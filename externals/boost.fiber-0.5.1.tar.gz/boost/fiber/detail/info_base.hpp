
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FIBERS_DETAIL_INFO_BASE_H
#define BOOST_FIBERS_DETAIL_INFO_BASE_H

#include <cstddef>
#include <stack>

#include <boost/config.hpp>
#include <boost/context.hpp>
#include <boost/function.hpp>
#include <boost/intrusive_ptr.hpp>
#include <boost/utility.hpp>

#include <boost/fiber/detail/config.hpp>
#include <boost/fiber/detail/interrupt_flags.hpp>
#include <boost/fiber/detail/state_flags.hpp>

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_PREFIX
#endif

namespace boost {
namespace fibers {

class strategy;

namespace detail {

struct BOOST_FIBER_DECL info_base : private noncopyable
{
	typedef intrusive_ptr< info_base >	ptr;
	typedef function< void() >			callable_type;
	typedef std::stack< callable_type >	callable_stack_type;

	unsigned int			use_count;
	int						priority;
	context					caller;
	context					callee;
	state_type				state;
	interrupt_type			interrupt;
	callable_stack_type		at_exit;
	strategy			*	st;

	info_base( std::size_t);

	virtual ~info_base() {}

	virtual void enter() = 0;
};

inline
void intrusive_ptr_add_ref( info_base * p)
{ ++p->use_count; }

inline
void intrusive_ptr_release( info_base * p)
{ if ( --p->use_count == 0) delete p; }

}}}

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_SUFFIX
#endif

#endif // BOOST_FIBERS_DETAIL_INFO_BASE_H
