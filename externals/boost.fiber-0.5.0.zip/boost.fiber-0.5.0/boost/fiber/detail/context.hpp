
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FIBERS_DETAIL_CONTEXT_H
#define BOOST_FIBERS_DETAIL_CONTEXT_H

#include <cstddef>

#include <boost/config.hpp>
#include <boost/move/move.hpp>

#include <boost/fiber/detail/config.hpp>

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_PREFIX
#endif

namespace boost {
namespace fibers {
namespace detail {

class BOOST_FIBER_DECL context
{
private:
	BOOST_MOVABLE_BUT_NOT_COPYABLE( context);

	struct impl_t;
	impl_t	*	ctx_;

public:
	typedef void ( * unspecified_bool_type)( context ***);

	static void unspecified_bool( context ***) {}

	static context current();

	static context create( void( fn)( void *), void * vp, std::size_t);

	static context create( void( fn)( void *), context const& next, void * vp, std::size_t);

	context();

	~context();

	context( BOOST_RV_REF( context) other);

	context & operator=( BOOST_RV_REF( context) other);

	void run();

	void jump_to( context & other);

	void swap( context & other);

	bool operator!() const;

	operator unspecified_bool_type() const;
};

inline
void swap( context & l, context & r)
{ l.swap( r); }

}}}

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_SUFFIX
#endif

#endif // BOOST_FIBERS_DETAIL_CONTEXT_H
