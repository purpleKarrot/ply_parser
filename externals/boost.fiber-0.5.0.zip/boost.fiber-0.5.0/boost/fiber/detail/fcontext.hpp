
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_FIBERS_DETAIL_FCONTEXT_H
#define BOOST_FIBERS_DETAIL_FCONTEXT_H

#include <boost/config.hpp>

#include <boost/fiber/detail/config.hpp>

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_PREFIX
#endif

namespace boost {
namespace fibers {
namespace detail {

typedef long int freg_t;

typedef freg_t fregset_t[BOOST_FIBER_NGREG];

typedef struct fstack	fstack_t;
struct fstack
{
	void	*	ss_base;
	void	*	ss_limit;
};

typedef struct fcontext	fcontext_t;
struct fcontext
{
	fregset_t		fc_reg;
	fstack_t		fc_stack;
	fcontext_t	*	fc_link;
	short int		fc_x87_cw;	
#if defined(_MSC_VER) && defined(_M_IX86)
	void		*	fc_excpt_lst;
#endif
};

extern "C" int BOOST_FIBER_CALLDECL get_fcontext( fcontext_t * fc);
extern "C" int BOOST_FIBER_CALLDECL set_fcontext( fcontext_t const* fc);
extern "C" int BOOST_FIBER_CALLDECL swap_fcontext( fcontext_t * ofc, fcontext_t const* nfc);
extern "C" int BOOST_FIBER_CALLDECL make_fcontext( fcontext_t const* fc, void (* fn)( void *), void * p);

}}}

#ifdef BOOST_HAS_ABI_HEADERS
#  include BOOST_ABI_SUFFIX
#endif

#endif // BOOST_FIBERS_DETAIL_FCONTEXT_H

