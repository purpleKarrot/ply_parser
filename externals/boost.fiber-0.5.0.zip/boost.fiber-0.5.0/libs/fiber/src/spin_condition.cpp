
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include "boost/fiber/spin_condition.hpp"

#include <boost/thread/thread.hpp>

namespace boost {
namespace fibers {

void
spin_condition::notify_( command cmd)
{
	enter_mtx_.lock();

	if ( 0 == waiters_.load() )
	{
		enter_mtx_.unlock();
		return;
	}

	command expected = SLEEPING;
	while ( ! cmd_.compare_exchange_strong( expected, cmd) )
	{
		if ( this_fiber::runs_as_fiber() )
			this_fiber::yield();
		else
			this_thread::yield();
		expected = SLEEPING;
	}
}

spin_condition::spin_condition() :
	cmd_( SLEEPING),
	waiters_( 0),
	enter_mtx_(),
	check_mtx_()
{}

void
spin_condition::notify_one()
{ notify_( NOTIFY_ONE); }

void
spin_condition::notify_all()
{ notify_( NOTIFY_ALL); }

}}
