#include <boost/fiber/strategy.hpp>

#include <utility>

#include <boost/assert.hpp>

#include <boost/fiber/detail/info.hpp>
#include <boost/fiber/detail/info_base.hpp>
#include <boost/fiber/detail/state_flags.hpp>
#include <boost/fiber/exceptions.hpp>

namespace boost {
namespace fibers {

BOOST_FIBER_TSSDECL fiber * strategy::active_fiber = 0;

bool
strategy::runs_as_fiber_()
{ return 0 != active_fiber; }

fiber::id
strategy::get_id_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	return active_fiber->get_id();
}

void
strategy::interruption_point_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	if ( detail::INTERRUPTION_ENABLED == active_fiber->info_->interrupt)
		throw fiber_interrupted();
}

bool
strategy::interruption_requested_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	return active_fiber->interruption_requested();
}

detail::interrupt_type &
strategy::interrupt_flags_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	return active_fiber->info_->interrupt;
}

bool
strategy::interruption_enabled_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	return ( active_fiber->info_->interrupt & detail::INTERRUPTION_ENABLED) != 0;
}

int
strategy::priority_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	return active_fiber->priority();
}

void
strategy::priority_( int prio)
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	active_fiber->priority( prio);
}

void
strategy::at_fiber_exit_( callable_type ca)
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	active_fiber->info_->at_exit.push( ca);
}

void
strategy::yield_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	if ( ! active_fiber->info_->st) throw scheduler_error("no valid scheduler");
	active_fiber->info_->st->yield();
}

void
strategy::cancel_()
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	if ( ! active_fiber->info_->st) throw scheduler_error("no valid scheduler");
	active_fiber->info_->st->cancel( active_fiber->get_id() );
}

void
strategy::submit_fiber_( fiber f)
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	if ( ! active_fiber->info_->st) throw scheduler_error("no valid scheduler");
	active_fiber->info_->st->add( f);
}

void
strategy::submit_fiber_( BOOST_RV_REF( fiber) f)
{
	if ( ! active_fiber) throw fiber_error("not a fiber");
	if ( ! active_fiber->info_->st) throw scheduler_error("no valid scheduler");
	active_fiber->info_->st->add( f);
}

strategy::strategy() :
	use_count_( 0), local_fiber( new fiber() )
{}

strategy::~strategy()
{ delete local_fiber; }

void
strategy::call( fiber & f)
{ f.info_->caller.jump_to( f.info_->callee); }

void
strategy::yield( fiber & f)
{ f.info_->callee.jump_to( f.info_->caller); }

void
strategy::attach( fiber & f)
{ f.info_->st = this; }

void
strategy::detach( fiber & f)
{ f.info_->st = 0; }

void
strategy::enable_interruption( fiber & f)
{
	// remove disabled flag
	f.info_->interrupt &= ~detail::INTERRUPTION_DISABLED;

	// set enabled flag
	f.info_->interrupt |= detail::INTERRUPTION_ENABLED;
}

bool
strategy::interruption_enabled( fiber const& f)
{ return detail::INTERRUPTION_ENABLED == f.info_->interrupt; }

bool
strategy::in_state_not_started( fiber const& f)
{ return detail::STATE_NOT_STARTED == f.info_->state; }

bool
strategy::in_state_ready( fiber const& f)
{ return detail::STATE_READY == f.info_->state; }

bool
strategy::in_state_running( fiber const& f)
{ return detail::STATE_RUNNING == f.info_->state; }

bool
strategy::in_state_wait_for_fiber( fiber const& f)
{ return detail::STATE_WAIT_FOR_FIBER == f.info_->state; }

bool
strategy::in_state_wait_for_object( fiber const& f)
{ return detail::STATE_WAIT_FOR_OBJECT == f.info_->state; }

bool
strategy::in_state_terminated( fiber const& f)
{ return detail::STATE_TERMINATED == f.info_->state; }

void
strategy::set_state_ready( fiber & f)
{ f.info_->state = detail::STATE_READY; }

void
strategy::set_state_running( fiber & f)
{ f.info_->state = detail::STATE_RUNNING; }

void
strategy::set_state_wait_for_fiber( fiber & f)
{ f.info_->state = detail::STATE_WAIT_FOR_FIBER; }

void
strategy::set_state_wait_for_object( fiber & f)
{ f.info_->state = detail::STATE_WAIT_FOR_OBJECT; }

void
strategy::set_state_terminated( fiber & f)
{ f.info_->state = detail::STATE_TERMINATED; }

}}
