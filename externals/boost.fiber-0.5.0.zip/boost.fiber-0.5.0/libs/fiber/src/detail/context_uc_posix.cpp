
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/fiber/detail/context.hpp>

extern "C" {
#include <ucontext.h>
}

#include <algorithm>
#include <cstdlib>
#include <cstring>

#include <boost/config.hpp>
#include <boost/system/system_error.hpp>

#include <boost/fiber/exceptions.hpp>

namespace boost {
namespace fibers {
namespace detail {

struct context::impl_t : public ucontext_t
{};

context
context::current()
{
	context cn;
	cn.ctx_ = new impl_t();
	return boost::move( cn);
}

context
context::create( void( fn)( void *), void * vp, std::size_t stack_size)
{
	context cn;
	cn.ctx_ = new impl_t();
	::getcontext( cn.ctx_);
	cn.ctx_->uc_stack.ss_size = stack_size;
#if defined(_POSIX_VERSION) && _POSIX_VERSION >= 199309
	int errno_ = ::posix_memalign( ( void **)( & cn.ctx_->uc_stack.ss_sp), ( std::size_t)( 2 * sizeof( void *) ), cn.ctx_->uc_stack.ss_size);
	if ( 0 != errno_)
		throw system::system_error(
			system::error_code(
				errno_,
				system::system_category) );
#else
#warning "no aligned memory allocation supported"
	cn.ctx_->uc_stack.ss_sp = std::malloc( cn.ctx_->uc_stack.ss_size);
	if ( 0 != cn.ctx_->uc_stack.ss_sp)
		throw system::system_error(
			system::error_code(
				system::errc::not_enough_memory,
				system::system_category) );
#endif
	typedef void fn_type( void *);
	typedef void ( * st_fn)();
	fn_type * fn_ptr( fn);
	::makecontext( cn.ctx_, ( st_fn)( fn_ptr), 1, vp);
	return boost::move( cn);
}

context
context::create( void( fn)( void *), context const& next, void * vp, std::size_t stack_size)
{
	if ( ! next) throw context_moved(); 
	context cn;
	cn.ctx_ = new impl_t();
	::getcontext( cn.ctx_);
	cn.ctx_->uc_stack.ss_size = stack_size;
#if defined(_POSIX_VERSION) && _POSIX_VERSION >= 199309
	int errno_ = ::posix_memalign( ( void **)( & cn.ctx_->uc_stack.ss_sp), ( std::size_t)( 2 * sizeof( void *) ), cn.ctx_->uc_stack.ss_size);
	if ( 0 != errno_)
		throw system::system_error(
			system::error_code(
				errno_,
				system::system_category) );
#else
#warning "no aligned memory allocation supported"
	cn.ctx_->uc_stack.ss_sp = std::malloc( cn.ctx_->uc_stack.ss_size);
	if ( 0 != cn.ctx_->uc_stack.ss_sp)
		throw system::system_error(
			system::error_code(
				system::errc::not_enough_memory,
				system::system_category) );
#endif
	typedef void fn_type( void *);
	typedef void ( * st_fn)();
	fn_type * fn_ptr( fn);
	cn.ctx_->uc_link = next.ctx_;
	::makecontext( cn.ctx_, ( st_fn)( fn_ptr), 1, vp);
	return boost::move( cn);
}

context::context() :
	ctx_( 0)
{}

context::~context()
{
	if ( ctx_)
	{
		std::free( ctx_->uc_stack.ss_sp);
		delete ctx_;
	}
}

context::context( BOOST_RV_REF( context) other) :
	ctx_( 0)
{ std::swap( ctx_, other.ctx_); }

context &
context::operator=( BOOST_RV_REF( context) other)
{
	if ( this != & other)
	{
		context tmp( other);
		swap( tmp);
	}
	return * this;
}

void
context::run()
{
	if ( ! ctx_) throw context_moved(); 
	::setcontext( ctx_);
}

void
context::jump_to( context & other)
{
	if ( ! ctx_ || ! other) throw context_moved(); 
	::swapcontext( ctx_, other.ctx_);
}

void
context::swap( context & other)
{ std::swap( ctx_, other.ctx_); }

bool
context::operator!() const
{ return 0 == ctx_; }

context::operator unspecified_bool_type() const
{ return 0 == ctx_ ? 0 : unspecified_bool; }

}}}
